export interface LoginForm {
  email: string;
  password: string;
}
