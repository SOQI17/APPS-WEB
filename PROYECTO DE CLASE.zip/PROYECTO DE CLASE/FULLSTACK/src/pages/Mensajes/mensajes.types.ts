export interface Mensaje {
  id: number;
  contenido: string;
}
